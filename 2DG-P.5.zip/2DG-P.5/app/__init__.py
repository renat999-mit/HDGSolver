from .convection import mkapp_convection
from .convection_diffusion import mkapp_convection_diffusion
from .wave import mkapp_wave
from .euler import mkapp_euler, eulereval