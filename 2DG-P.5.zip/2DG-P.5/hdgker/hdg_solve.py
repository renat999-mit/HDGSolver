import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

from master import shape2d

__all__ = ['hdg_solve']

def localprob(dg, master, m, source, param, bf, tau_val):
    """
    localprob solves the local convection-diffusion problems for the hdg method
       dg:              dg nodes
       master:          master element structure
       m[3*nps, ncol]:  values of uhat at the element edges (ncol is the
                        number of right hand sides. i.e a different local 
                        problem is solved for each right hand side)
       source:          source term
       param:           param['kappa']= diffusivity coefficient
                        param['c'] = convective velocity
       umf[npl, ncol]:  uh local solution
       qmf[npl,2,ncol]: qh local solution
    """
    porder = master.porder

    kappa = param['kappa']
    c     = param['c']
    # taud  = kappa
    
    taud_interior = tau_val[0]
    taud_boundary = tau_val[1]

    nps   = porder+1
    ncol  = m.shape[1]
    npl   = dg.shape[0]

    perm = master.perm[:,:,0]

    qmf = np.zeros((npl, 2, ncol))
    
    Fx = np.zeros((npl, ncol))
    Fy = np.zeros((npl, ncol))
    Fu = np.zeros((npl, ncol))
    
    # Volume integral
    shap = master.shap[:,0,:]
    shapxi = master.shap[:,1,:]
    shapet = master.shap[:,2,:]
    shapxig = shapxi @ np.diag(master.gwgh)
    shapetg = shapet @ np.diag(master.gwgh)

    xxi = dg[:,0] @ shapxi
    xet = dg[:,0] @ shapet
    yxi = dg[:,1] @ shapxi
    yet = dg[:,1] @ shapet
    jac = xxi * yet - xet * yxi
    shapx =   shapxig @ np.diag(yet) - shapetg @ np.diag(yxi)
    shapy = - shapxig @ np.diag(xet) + shapetg @ np.diag(xxi)
    M  = (shap @ np.diag(master.gwgh * jac) @ shap.T)/kappa
    Cx = shap @ shapx.T
    Cy = shap @ shapy.T

    D = -c[0]*Cx.T - c[1]*Cy.T

    if source:
        pg = shap.T @ dg
        src = source( pg)
        Fu = shap @ np.diag(master.gwgh*jac) @ src
    
    Fu = np.reshape(Fu,(npl,ncol))
    
    sh1d = np.squeeze(master.sh1d[:,0,:])
    for s in range(3):
        
        if s in bf:
            
            taud = taud_boundary
            
        else:
            
            taud = taud_interior
            
        xxi = np.squeeze(master.sh1d[:,1,:]).T @ dg[perm[:,s], 0]
        yxi = np.squeeze(master.sh1d[:,1,:]).T @ dg[perm[:,s], 1]
        dsdxi = np.sqrt(xxi**2 + yxi**2)
        nl = np.column_stack((yxi/dsdxi, -xxi/dsdxi))
        
        cnl = c[0]*nl[:,0] + c[1]*nl[:,1]
    
        tauc = np.abs(cnl)
        tau  = taud + tauc

        D[np.ix_(perm[:,s], perm[:,s])] = D[np.ix_(perm[:,s], perm[:,s])] + sh1d @ np.diag(master.gw1d*dsdxi*tau) @ sh1d.T
    
    for s in range(3):
        
        if s in bf:
            
            taud = taud_boundary
            
        else:
            
            taud = taud_interior
        
        xxi = np.squeeze(master.sh1d[:,1,:]).T @ dg[perm[:,s], 0]
        yxi = np.squeeze(master.sh1d[:,1,:]).T @ dg[perm[:,s], 1]
        dsdxi = np.sqrt(xxi**2 + yxi**2)
        nl = np.column_stack((yxi/dsdxi, -xxi/dsdxi))
       
        for icol in range(ncol):     # Loop over all the right-hand-sides
            ml = m[s*nps:(s+1)*nps, icol]
       
            cnl = c[0]*nl[:,0] + c[1]*nl[:,1]
    
            tauc = np.abs(cnl)
            tau  = taud + tauc
    
            Fx[perm[:,s], icol] = Fx[perm[:,s], icol] - sh1d @ np.diag(master.gw1d*dsdxi*nl[:,0]) @ sh1d.T @ ml
            Fy[perm[:,s], icol] = Fy[perm[:,s], icol] - sh1d @ np.diag(master.gw1d*dsdxi*nl[:,1]) @ sh1d.T @ ml

            Fu[perm[:,s], icol] = Fu[perm[:,s], icol] - sh1d @ np.diag(master.gw1d*dsdxi*(cnl-tau)) @ sh1d.T @ ml

    M1Fx = np.linalg.solve(M, Fx)
    M1Fy = np.linalg.solve(M, Fy)

    M1   = np.linalg.inv(M)
    
    umf = np.linalg.solve(D + Cx @ M1 @ Cx.T + Cy @ M1 @ Cy.T, Fu - Cx @ M1Fx - Cy @ M1Fy)
    qmf[:,0,:] = M1Fx + np.linalg.solve(M, Cx.T @ umf)
    qmf[:,1,:] = M1Fy + np.linalg.solve(M, Cy.T @ umf)

    return umf, qmf


def elemmat_hdg(dg, master, source, param, bf, tau_val):
    """
    elemmat_hdg calcualtes the element and force vectors for the hdg method
 
       dg:              dg nodes
       master:          master element structure
       source:          source term
       param:           param['kappa']   = diffusivity coefficient
                        param['c'] = convective velocity
       ae[3*nps,3*nps]: element matrix (nps is nimber of points per edge)
       fe[3*nps,1]:     element forcer vector
    """
    nps   = master.porder + 1
    npl   = dg.shape[0]
    
    perm = master.perm[:,:,0]
    
    kappa = param['kappa']
    c     = param['c']
    # taud  = kappa
    taud_interior = tau_val[0]
    taud_boundary = tau_val[1]

    mu = np.identity(3*nps)
    um0, qm0 = localprob(dg, master, mu, None, param, bf, tau_val)
    
      
    m = np.zeros((3*nps,1))
    u0f, q0f = localprob(dg, master, m, source, param, bf, tau_val)
    
    M = np.zeros((3*nps,3*nps))
    
    Cx = np.zeros((3*nps,npl))
    Cy = np.zeros((3*nps,npl))
    
    E = np.zeros((3*nps,npl))
    
    sh1d = np.squeeze(master.sh1d[:,0,:])
    
    for s in range(3):
        
        if s in bf:
            
            taud = taud_boundary
            
        else:
            
            taud = taud_interior
        
        xxi = np.squeeze(master.sh1d[:,1,:]).T @ dg[perm[:,s], 0]
        yxi = np.squeeze(master.sh1d[:,1,:]).T @ dg[perm[:,s], 1]
        dsdxi = np.sqrt(xxi**2 + yxi**2)
        nl = np.column_stack((yxi/dsdxi, -xxi/dsdxi))
        
        cnl = c[0]*nl[:,0] + c[1]*nl[:,1]
    
        tauc = np.abs(cnl)
        tau  = taud + tauc
        
        idx1dSav = np.arange(nps*s,nps*s+nps)
        
        M[np.ix_(idx1dSav,idx1dSav)] = sh1d @ np.diag(master.gw1d*dsdxi*(tau-cnl)) @ sh1d.T
        
        Cx[np.ix_(idx1dSav,perm[:,s])] = sh1d @ np.diag(master.gw1d*dsdxi*nl[:,0]) @ sh1d.T
        Cy[np.ix_(idx1dSav,perm[:,s])] = sh1d @ np.diag(master.gw1d*dsdxi*nl[:,1]) @ sh1d.T
        
        E[np.ix_(idx1dSav,perm[:,s])] = sh1d @ np.diag(master.gw1d*dsdxi*tau) @ sh1d.T
    
    ae = M - np.hstack([Cx,Cy,E]) @ np.vstack([qm0[:,0,:],qm0[:,1,:],um0])
    
    fe = np.squeeze(np.hstack([Cx,Cy,E]) @ np.vstack([q0f[:,0,:],q0f[:,1,:],u0f]))
    
    return ae, fe


def hdg_solve(master, mesh, source, dbc, param, tau_val):
    """
    hdg_solve solves the convection-diffusion equation using the hdg method.
    [uh,qh,uhath]=hdg_solve(mesh,master,source,dbc,param)
 
       master:       master structure
       mesh:         mesh structure
       source:       source term
       dbc:          dirichlet data 
       param:        param['kappa']   = diffusivity coefficient
                     param['c'] = convective velocity
       uh:           approximate scalar variable
       qh:           approximate flux
       uhath:        approximate trace                              
    """

    nps = mesh.porder + 1
    npl = mesh.dgnodes.shape[0]
    nt  = mesh.t.shape[0]
    nf  = mesh.f.shape[0]

    ae  = np.zeros((3*nps, 3*nps, nt))
    fe  = np.zeros((3*nps, nt))
    
    boundary_faces = np.squeeze(np.where(mesh.f[:,3] < 0))

    for i in range(nt):
        
        faces = np.absolute(mesh.t2f[i]) - 1
        
        bf = []
        for j in range(len(faces)):
            
            if faces[j] in boundary_faces:
                
                bf.append(j)
                
        ae[:,:,i], fe[:,i] = elemmat_hdg( mesh.dgnodes[:,:,i], master, source, param, bf, tau_val)
        
    
    elcon = np.zeros((3*nps,nt),dtype=int)
    
    for e in range(nt):
        
        for s in range(3):
            
            reverse = False
            
            f = mesh.t2f[e,s]
            
            if f < 0:
                
                reverse = True
                
            f = abs(f) - 1
            
            global_nodes = np.arange(f*nps,(f+1)*nps,dtype=int)
            
            if reverse:
                
                global_nodes = global_nodes[::-1]
                
            elcon[s*nps:(s+1)*nps,e] = global_nodes
    
    H = np.zeros((nps*mesh.f.shape[0],nps*mesh.f.shape[0]))
    R = np.zeros(nps*mesh.f.shape[0])
    
    for e in range(nt):
        
        H[np.ix_(elcon[:,e], elcon[:,e])] += ae[:,:,e]
        
        R[elcon[:,e]] += fe[:,e]
    
    #Apply Dirichlet BC
    
    for f in boundary_faces:
        
        e, local_f = np.where(np.absolute(mesh.t2f)-1 == f)
        
        global_nodes = np.arange(f*nps,(f+1)*nps,dtype=int)
        
        if mesh.t2f[e,local_f] < 0:
            
            local_nodes = master.perm[:,local_f,1]
            
            global_nodes = global_nodes[::-1]
            
            
        else:
            
            local_nodes = master.perm[:,local_f,0]
            
        dirichlet_data = dbc(mesh.dgnodes[local_nodes,:,e])
        
        H[global_nodes,:] = np.zeros((nps,H.shape[1]))
        
        for node in global_nodes:
            
            H[node,node] = 1

        R[global_nodes] = np.squeeze(dirichlet_data)
    
    uhath = spsolve(H,R)
    uhath = np.reshape(uhath, (len(uhath),1))
    
    uh = np.zeros((npl,nt))
    qh = np.zeros((npl,2,nt))
    
    for e in range(nt):
        
        faces = np.absolute(mesh.t2f[e]) - 1
        
        bf = []
        for j in range(len(faces)):
            
            if faces[j] in boundary_faces:
                
                bf.append(j)
                
        result_u, result_q = localprob(mesh.dgnodes[:,:,e], master, uhath[elcon[:,e],:], source, param, bf, tau_val)  
        uh[:,e] = np.squeeze(result_u)
        qh[:,0,e] = np.squeeze(result_q[:,0])
        qh[:,1,e] = np.squeeze(result_q[:,1])
        
    return uh, qh, uhath